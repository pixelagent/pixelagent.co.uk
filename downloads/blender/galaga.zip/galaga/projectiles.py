"""
Galaga Projectiles Module
Handles bullets, collisions, and explosions
"""

import bpy
import random
from .constants import *


class Bullet:
    """Bullet projectile"""
    
    def __init__(self, x, y, is_player_bullet=True):
        self.x = x
        self.y = y
        self.is_player_bullet = is_player_bullet
        self.collision_radius = BULLET_COLLISION_RADIUS
        self.speed = PLAYER_BULLET_SPEED if is_player_bullet else ENEMY_BULLET_SPEED
        self.direction = 1 if is_player_bullet else -1
        self.alive = True
        self.blender_object = None
        
    def create(self):
        """Create bullet mesh"""
        bpy.ops.mesh.primitive_uv_sphere_add(
            segments=8,
            ring_count=4,
            radius=0.4,
            location=(self.x, self.y, 0)
        )
        bullet = bpy.context.active_object
        bullet.name = "PlayerBullet" if self.is_player_bullet else "EnemyBullet"
        
        mat_name = "PlayerBulletMat" if self.is_player_bullet else "EnemyBulletMat"
        
        # Check if material exists
        if mat_name in bpy.data.materials:
            mat = bpy.data.materials[mat_name]
        else:
            mat = bpy.data.materials.new(name=mat_name)
            mat.use_nodes = True
            nodes = mat.node_tree.nodes
            principled = nodes.get("Principled BSDF")
            color = COLOR_PLAYER_BULLET if self.is_player_bullet else COLOR_ENEMY_BULLET
            principled.inputs["Base Color"].default_value = color
            principled.inputs["Emission Color"].default_value = color
            principled.inputs["Emission Strength"].default_value = 2.0
        
        bullet.data.materials.append(mat)
        self.blender_object = bullet
        return bullet
    
    def update(self, dt):
        """Update bullet position"""
        self.y += self.speed * self.direction * dt
        self.update_position()
        
        # Check if out of bounds
        if self.y > PLAY_AREA_MAX_Y + 5 or self.y < PLAY_AREA_MIN_Y - 5:
            self.alive = False
    
    def update_position(self):
        """Update Blender object position"""
        if self.blender_object:
            self.blender_object.location.x = self.x
            self.blender_object.location.y = self.y
    
    def cleanup(self):
        """Remove bullet from scene"""
        if self.blender_object:
            bpy.data.objects.remove(self.blender_object, do_unlink=True)
            self.blender_object = None


class Explosion:
    """Explosion effect"""
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.lifetime = 0.5  # seconds
        self.age = 0
        self.blender_object = None
        
    def create(self):
        """Create explosion effect"""
        # Create multiple spheres for explosion
        bpy.ops.mesh.primitive_uv_sphere_add(
            segments=8,
            ring_count=4,
            radius=1.5,
            location=(self.x, self.y, 0)
        )
        expl = bpy.context.active_object
        expl.name = "Explosion"
        
        # Scale up
        expl.scale = (0.5, 0.5, 0.5)
        
        # Orange emissive material
        mat = bpy.data.materials.new(name="ExplosionMat")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        principled = nodes.get("Principled BSDF")
        principled.inputs["Base Color"].default_value = (1.0, 0.5, 0.0, 1.0)
        principled.inputs["Emission Color"].default_value = (1.0, 0.5, 0.0, 1.0)
        principled.inputs["Emission Strength"].default_value = 3.0
        
        expl.data.materials.append(mat)
        self.blender_object = expl
        return expl
    
    def update(self, dt):
        """Update explosion"""
        self.age += dt
        
        # Expand then contract
        progress = self.age / self.lifetime
        if progress < 0.5:
            scale = progress * 2
        else:
            scale = 2 - progress * 2
        
        if self.blender_object:
            self.blender_object.scale = (scale, scale, scale)
        
        return self.age >= self.lifetime
    
    def cleanup(self):
        """Remove explosion"""
        if self.blender_object:
            bpy.data.objects.remove(self.blender_object, do_unlink=True)
            self.blender_object = None


class ProjectileManager:
    """Manages all bullets and effects"""
    
    def __init__(self):
        self.player_bullets = []
        self.enemy_bullets = []
        self.explosions = []
        self.shoot_cooldown = 0.2
        self.shoot_timer = 0
        
    def player_shoot(self, x, y):
        """Create player bullet"""
        if len(self.player_bullets) < MAX_PLAYER_BULLETS and self.shoot_timer <= 0:
            bullet = Bullet(x, y + 1, True)
            bullet.create()
            self.player_bullets.append(bullet)
            self.shoot_timer = self.shoot_cooldown
    
    def enemy_shoot(self, x, y):
        """Create enemy bullet"""
        bullet = Bullet(x, y - 1, False)
        bullet.create()
        self.enemy_bullets.append(bullet)
    
    def create_explosion(self, x, y):
        """Create explosion effect"""
        expl = Explosion(x, y)
        expl.create()
        self.explosions.append(expl)
    
    def update(self, dt):
        """Update all projectiles"""
        # Update timers
        if self.shoot_timer > 0:
            self.shoot_timer -= dt
        
        # Update player bullets
        for bullet in self.player_bullets[:]:
            bullet.update(dt)
            if not bullet.alive:
                bullet.cleanup()
                self.player_bullets.remove(bullet)
        
        # Update enemy bullets
        for bullet in self.enemy_bullets[:]:
            bullet.update(dt)
            if not bullet.alive:
                bullet.cleanup()
                self.enemy_bullets.remove(bullet)
        
        # Update explosions
        for expl in self.explosions[:]:
            if expl.update(dt):
                expl.cleanup()
                self.explosions.remove(expl)
    
    def get_player_bullet_at(self, x, y, radius):
        """Find player bullet at position"""
        for bullet in self.player_bullets:
            dx = bullet.x - x
            dy = bullet.y - y
            if (dx*dx + dy*dy)**0.5 < radius + bullet.collision_radius:
                return bullet
        return None
    
    def get_enemy_bullet_at(self, x, y, radius):
        """Find enemy bullet at position"""
        for bullet in self.enemy_bullets:
            dx = bullet.x - x
            dy = bullet.y - y
            if (dx*dx + dy*dy)**0.5 < radius + bullet.collision_radius:
                return bullet
        return None
    
    def cleanup(self):
        """Remove all projectiles"""
        for bullet in self.player_bullets:
            bullet.cleanup()
        for bullet in self.enemy_bullets:
            bullet.cleanup()
        for expl in self.explosions:
            expl.cleanup()
        
        self.player_bullets = []
        self.enemy_bullets = []
        self.explosions = []
        
        # Clean up shared materials
        for mat_name in ("PlayerBulletMat", "EnemyBulletMat"):
            if mat_name in bpy.data.materials:
                bpy.data.materials.remove(bpy.data.materials[mat_name])
