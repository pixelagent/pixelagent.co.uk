"""
Galaga Player Ship Module
Handles player creation, movement, and shooting
"""

import bpy
import math
from .constants import *


class Player:
    """Player ship controller"""
    
    def __init__(self):
        self.x = PLAYER_START_X
        self.y = PLAYER_START_Y
        self.speed = PLAYER_SPEED
        self.collision_radius = PLAYER_COLLISION_RADIUS
        self.lives = 3
        self.visible = True
        self.invulnerable = False
        self.invulnerable_timer = 0
        self.blender_object = None
        self.is_alive = True
        
    def create(self):
        """Create the player ship in Blender"""
        # Create player ship mesh
        bpy.ops.mesh.primitive_cone_add(
            vertices=8,
            radius1=1.2,
            radius2=0,
            depth=2,
            location=(self.x, self.y, 0)
        )
        player = bpy.context.active_object
        player.name = "PlayerShip"
        
        # Rotate to point upward (cone points up by default, we want tip up)
        player.rotation_euler = (math.pi, 0, 0)
        
        # Create material
        mat = bpy.data.materials.new(name="PlayerMaterial")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        principled = nodes.get("Principled BSDF")
        principled.inputs["Base Color"].default_value = COLOR_PLAYER
        principled.inputs["Emission Color"].default_value = COLOR_PLAYER
        principled.inputs["Emission Strength"].default_value = 0.8
        
        player.data.materials.append(mat)
        
        # Create thruster (smaller cone at bottom)
        bpy.ops.mesh.primitive_cone_add(
            vertices=8,
            radius1=0.6,
            radius2=0.3,
            depth=1,
            location=(self.x, self.y - 1.5, 0)
        )
        thruster = bpy.context.active_object
        thruster.name = "PlayerThruster"
        thruster.parent = player
        
        # Thruster material
        mat_thrust = bpy.data.materials.new(name="ThrusterMaterial")
        mat_thrust.use_nodes = True
        nodes = mat_thrust.node_tree.nodes
        principled = nodes.get("Principled BSDF")
        principled.inputs["Base Color"].default_value = COLOR_PLAYER_THRUSTER
        principled.inputs["Emission Color"].default_value = COLOR_PLAYER_THRUSTER
        principled.inputs["Emission Strength"].default_value = 2.0
        
        thruster.data.materials.append(mat_thrust)
        
        self.blender_object = player
        return player
    
    def move_left(self, dt):
        """Move player left"""
        if not self.is_alive:
            return
        self.x -= self.speed * dt
        self.x = max(PLAY_AREA_MIN_X + 2, self.x)
        self.update_position()
    
    def move_right(self, dt):
        """Move player right"""
        if not self.is_alive:
            return
        self.x += self.speed * dt
        self.x = min(PLAY_AREA_MAX_X - 2, self.x)
        self.update_position()
    
    def update_position(self):
        """Update Blender object position"""
        if self.blender_object:
            self.blender_object.location.x = self.x
            self.blender_object.location.y = self.y
    
    def get_position(self):
        """Get current position"""
        return (self.x, self.y)
    
    def hit(self):
        """Handle player getting hit"""
        if self.invulnerable:
            return False
            
        self.lives -= 1
        self.invulnerable = True
        self.invulnerable_timer = 2.0  # 2 seconds invulnerability
        
        if self.lives <= 0:
            self.die()
            return True
        return False
    
    def die(self):
        """Player death"""
        self.is_alive = False
        if self.blender_object:
            self.blender_object.hide_set(True)
    
    def respawn(self):
        """Respawn player"""
        self.x = PLAYER_START_X
        self.y = PLAYER_START_Y
        self.is_alive = True
        self.invulnerable = True
        self.invulnerable_timer = 2.0
        self.update_position()
        if self.blender_object:
            self.blender_object.hide_set(False)
    
    def update(self, dt):
        """Update player state"""
        if self.invulnerable:
            self.invulnerable_timer -= dt
            if self.invulnerable_timer <= 0:
                self.invulnerable = False
                # Make player visible
                if self.blender_object:
                    self.blender_object.hide_set(False)
            else:
                # Flash the player visibility
                if self.blender_object:
                    flash = int(self.invulnerable_timer * 10) % 2
                    self.blender_object.hide_set(flash == 0)
    
    def cleanup(self):
        """Remove player from scene"""
        if self.blender_object:
            # Delete children first
            for child in self.blender_object.children:
                bpy.data.objects.remove(child, do_unlink=True)
            bpy.data.objects.remove(self.blender_object, do_unlink=True)
            self.blender_object = None
