"""
Galaga Enemy Module
Handles enemy creation, formations, and AI behaviors
"""

import bpy
import random
import math
from .constants import *


class Enemy:
    """Individual enemy ship"""
    
    def __init__(self, enemy_type, grid_x, grid_y):
        self.type = enemy_type
        self.grid_x = grid_x  # Position in formation
        self.grid_y = grid_y
        self.x = 0
        self.y = 0
        self.start_x = 0
        self.start_y = 0
        self.collision_radius = ENEMY_COLLISION_RADIUS
        self.points = self._get_points()
        self.alive = True
        self.blender_object = None
        self.diving = False
        self.dive_target_x = 0
        self.dive_progress = 0
        self.returning = False
        self.column_base_x = 0.0  # Fixed per-column position
        self.formation_shift = 0.0  # Cumulative formation drift
        
    def _get_points(self):
        """Get points for destroying this enemy type"""
        if self.type == ENEMY_TYPE_FLYER:
            return POINTS_FLYER
        elif self.type == ENEMY_TYPE_BUTTERFLY:
            return POINTS_BUTTERFLY
        elif self.type == ENEMY_TYPE_BOSS:
            return POINTS_BOSS
        return 50
    
    def get_color(self):
        """Get color for enemy type"""
        if self.type == ENEMY_TYPE_FLYER:
            return COLOR_ENEMY_FLYER
        elif self.type == ENEMY_TYPE_BUTTERFLY:
            return COLOR_ENEMY_BUTTERFLY
        elif self.type == ENEMY_TYPE_BOSS:
            return COLOR_ENEMY_BOSS
        return COLOR_ENEMY_FLYER
    
    def create(self):
        """Create enemy mesh in Blender"""
        if self.type == ENEMY_TYPE_FLYER:
            return self._create_flyer()
        elif self.type == ENEMY_TYPE_BUTTERFLY:
            return self._create_butterfly()
        elif self.type == ENEMY_TYPE_BOSS:
            return self._create_boss()
        return self._create_flyer()
    
    def _create_flyer(self):
        """Create flyer enemy (simple diamond shape)"""
        # Create a flattened icosphere
        bpy.ops.mesh.primitive_ico_sphere_add(
            subdivisions=1,
            radius=1.0,
            location=(self.x, self.y, 0)
        )
        enemy = bpy.context.active_object
        enemy.name = f"Enemy_Flyer_{self.grid_x}_{self.grid_y}"
        
        # Scale to make it flatter
        enemy.scale = (1.2, 0.6, 1.0)
        
        # Material
        mat = bpy.data.materials.new(name=f"FlyerMat_{self.grid_x}_{self.grid_y}")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        principled = nodes.get("Principled BSDF")
        color = self.get_color()
        principled.inputs["Base Color"].default_value = color
        principled.inputs["Emission Color"].default_value = color
        principled.inputs["Emission Strength"].default_value = 0.5
        
        enemy.data.materials.append(mat)
        self.blender_object = enemy
        return enemy
    
    def _create_butterfly(self):
        """Create butterfly enemy (wing shape)"""
        # Create UV sphere and scale
        bpy.ops.mesh.primitive_uv_sphere_add(
            segments=8,
            ring_count=4,
            radius=1.0,
            location=(self.x, self.y, 0)
        )
        enemy = bpy.context.active_object
        enemy.name = f"Enemy_Butterfly_{self.grid_x}_{self.grid_y}"
        
        # Scale to look like butterfly wings
        enemy.scale = (1.5, 0.5, 0.8)
        
        mat = bpy.data.materials.new(name=f"ButterflyMat_{self.grid_x}_{self.grid_y}")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        principled = nodes.get("Principled BSDF")
        color = self.get_color()
        principled.inputs["Base Color"].default_value = color
        principled.inputs["Emission Color"].default_value = color
        principled.inputs["Emission Strength"].default_value = 0.5
        
        enemy.data.materials.append(mat)
        self.blender_object = enemy
        return enemy
    
    def _create_boss(self):
        """Create boss enemy (larger, more complex)"""
        # Main body
        bpy.ops.mesh.primitive_uv_sphere_add(
            segments=16,
            ring_count=8,
            radius=1.3,
            location=(self.x, self.y, 0)
        )
        enemy = bpy.context.active_object
        enemy.name = f"Enemy_Boss_{self.grid_x}_{self.grid_y}"
        
        mat = bpy.data.materials.new(name=f"BossMat_{self.grid_x}_{self.grid_y}")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        principled = nodes.get("Principled BSDF")
        color = self.get_color()
        principled.inputs["Base Color"].default_value = color
        principled.inputs["Emission Color"].default_value = color
        principled.inputs["Emission Strength"].default_value = 0.6
        
        enemy.data.materials.append(mat)
        self.blender_object = enemy
        return enemy
    
    def set_formation_position(self, offset_x, offset_y):
        """Set position in formation"""
        self.column_base_x = offset_x  # Fixed per-column position
        self.formation_shift = 0.0  # Cumulative formation drift
        self.start_y = offset_y
        self.x = offset_x
        self.y = offset_y
        self.update_blender_position()
    
    def update_blender_position(self):
        """Update Blender object position"""
        if self.blender_object and self.alive:
            self.blender_object.location.x = self.x
            self.blender_object.location.y = self.y
    
    def start_dive(self, target_x):
        """Start dive attack"""
        self.diving = True
        self.returning = False
        self.dive_target_x = target_x
        self.dive_progress = 0
        self.start_x = self.x
        self.start_y = self.y
    
    def update(self, dt, formation_move, formation_shift):
        """Update enemy state"""
        if not self.alive:
            return
            
        if self.diving:
            self._update_dive(dt)
        elif self.returning:
            self._update_return(dt, formation_shift)
        else:
            # In formation - update formation shift and apply movement
            self.formation_shift += formation_move
            self.x = self.column_base_x + self.formation_shift
            self.update_blender_position()
    
    def _update_dive(self, dt):
        """Update dive attack movement"""
        self.dive_progress += dt * 2
        
        if self.type == ENEMY_TYPE_FLYER:
            # Straight down then curve
            self.y -= ENEMY_DIVE_SPEED * dt
            # Move toward target
            dx = (self.dive_target_x - self.x) * dt * 2
            self.x += dx
            
        elif self.type == ENEMY_TYPE_BUTTERFLY:
            # Curved pattern
            self.y -= ENEMY_DIVE_SPEED * dt
            self.x += (self.dive_target_x - self.start_x) * dt * 3 * (1 - self.dive_progress)
            
        elif self.type == ENEMY_TYPE_BOSS:
            # Complex pattern - oscillate
            self.y -= ENEMY_DIVE_SPEED * 0.7 * dt
            self.x += (self.dive_target_x - self.start_x) * dt * 2
            # Add some oscillation
            self.x += math.sin(self.dive_progress * 5) * dt * 5
        
        self.update_blender_position()
        
        # Check if reached bottom - start returning
        if self.y < PLAY_AREA_MIN_Y - 5:
            self.returning = True
            self.diving = False
    
    def _update_return(self, dt, formation_shift):
        """Return to formation"""
        # Return to current formation position: column base + current shift
        target_x = self.column_base_x + formation_shift
        target_y = self.start_y
        
        return_speed = 15
        
        dx = target_x - self.x
        dy = target_y - self.y
        dist = (dx**2 + dy**2)**0.5
        
        if dist < 1:
            self.returning = False
            self.x = target_x
            self.y = target_y
            self.formation_shift = formation_shift
        else:
            self.x += (dx / dist) * return_speed * dt
            self.y += (dy / dist) * return_speed * dt
        
        self.update_blender_position()
    
    def cleanup(self):
        """Remove enemy from scene"""
        if self.blender_object:
            bpy.data.objects.remove(self.blender_object, do_unlink=True)
            self.blender_object = None


class EnemyFormation:
    """Manages enemy formation"""
    
    def __init__(self):
        self.enemies = []
        self.move_direction = 1
        self.move_timer = 0
        self.move_interval = 0.5  # Time between formation moves
        self.formation_amplitude = 8  # How far formation moves side to side
        self.current_offset = 0
        self.start_x = 0
        self.alive_count = 0
        self.dive_cooldown = DIVE_ATTACK_COOLDOWN
        self.level = 1
        
    def create(self):
        """Create enemy formation"""
        self.enemies = []
        
        # Create enemies in formation
        # Rows 0-1: Boss (top)
        # Rows 2-3: Butterfly  
        # Rows 4: Flyer (bottom)
        
        for row in range(ENEMY_ROWS):
            for col in range(ENEMY_COLS):
                if row < 2:
                    enemy_type = ENEMY_TYPE_BOSS
                elif row < 4:
                    enemy_type = ENEMY_TYPE_BUTTERFLY
                else:
                    enemy_type = ENEMY_TYPE_FLYER
                
                enemy = Enemy(enemy_type, col, row)
                enemy.create()
                
                # Calculate formation position
                offset_x = (col - ENEMY_COLS/2 + 0.5) * ENEMY_SPACING_X
                offset_y = ENEMY_FORMATION_START_Y - row * ENEMY_SPACING_Y
                
                enemy.set_formation_position(offset_x, offset_y)
                self.enemies.append(enemy)
        
        self.start_x = 0
        self.alive_count = len(self.enemies)
        self._update_alive_count()
    
    def _update_alive_count(self):
        """Count alive enemies"""
        self.alive_count = sum(1 for e in self.enemies if e.alive)
    
    def update(self, dt):
        """Update formation"""
        if self.alive_count == 0:
            return
            
        # Formation side-to-side movement
        self.move_timer += dt
        if self.move_timer >= self.move_interval:
            self.move_timer = 0
            self.move_direction *= -1
        
        # Calculate current offset
        offset_change = self.move_direction * ENEMY_MOVE_SPEED * dt
        self.current_offset += offset_change
        self.current_offset = max(-self.formation_amplitude, 
                                   min(self.formation_amplitude, self.current_offset))
        
        formation_move = self.move_direction * ENEMY_MOVE_SPEED * dt
        
        # Update dive cooldown
        self.dive_cooldown -= dt
        
        # Update all enemies
        for enemy in self.enemies:
            if enemy.alive:
                enemy.update(dt, formation_move, self.current_offset)
                
                # Trigger dive attacks
                if not enemy.diving and not enemy.returning and self.dive_cooldown <= 0:
                    if self._should_dive(enemy):
                        target_x = random.uniform(PLAY_AREA_MIN_X + 5, PLAY_AREA_MAX_X - 5)
                        enemy.start_dive(target_x)
        
        # Reset dive cooldown when all enemies return
        if self.dive_cooldown <= 0:
            diving = any(e.diving or e.returning for e in self.enemies if e.alive)
            if not diving:
                self.dive_cooldown = DIVE_ATTACK_COOLDOWN / (1 + self.level * 0.2)
    
    def _should_dive(self, enemy):
        """Determine if enemy should dive"""
        chance = ENEMY_DIVE_CHANCE * (1 + self.level * 0.3)
        
        # Higher rows more likely to dive
        chance *= (1 + enemy.grid_y * 0.3)
        
        return random.random() < chance
    
    def get_enemy_at(self, x, y, radius):
        """Find enemy at position (for collision)"""
        for enemy in self.enemies:
            if enemy.alive:
                dx = enemy.x - x
                dy = enemy.y - y
                if (dx*dx + dy*dy)**0.5 < radius + enemy.collision_radius:
                    return enemy
        return None
    
    def get_random_diving_enemy(self):
        """Get a random enemy that's currently diving"""
        divers = [e for e in self.enemies if e.alive and (e.diving or e.returning)]
        if divers:
            return random.choice(divers)
        return None
    
    def is_cleared(self):
        """Check if all enemies are cleared"""
        return self.alive_count == 0
    
    def cleanup(self):
        """Remove all enemies"""
        for enemy in self.enemies:
            enemy.cleanup()
        self.enemies = []
