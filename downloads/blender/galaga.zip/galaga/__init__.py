"""
Galaga - A Classic Arcade Space Shooter for Blender
====================================================

A fully playable Galaga-style game that runs inside Blender.
Play directly in the Blender viewport!

Installation:
1. Copy this 'galaga' folder to your Blender addons directory
   (e.g., ~/.config/blender/3.x/scripts/addons/)
2. Enable the addon in Blender Preferences > Add-ons
3. Run the game from the sidebar panel

Controls:
- Left/Right Arrow or A/D: Move ship
- Spacebar: Fire
- P: Pause/Resume
- R: Restart (when game over)
- Escape: Stop game and return to Blender
"""

bl_info = {
    "name": "Galaga - Arcade Space Shooter",
    "description": "Play Galaga directly in Blender viewport",
    "author": "Galaga Games",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "Sidebar > Galaga",
    "category": "Game",
}

import bpy
from bpy.props import BoolProperty
from .game import GalagaGame, create_game, destroy_game, get_game

# Global variables
_game_timer = None
_modal_operator = None


class GALAGA_OT_start_game(bpy.types.Operator):
    """Start the Galaga game"""
    bl_idname = "galaga.start_game"
    bl_label = "Start Game"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        global _game_timer, _modal_operator
        
        # Check if game already running
        if get_game():
            self.report({'WARNING'}, "Game already running!")
            return {'CANCELLED'}
        
        # Create game
        create_game()
        game = get_game()
        
        # Start game timer
        _game_timer = bpy.app.timers.register(
            game_callback,
            first_interval=1.0/60.0,
            persistent=True
        )
        
        # Execute to start modal
        bpy.ops.galaga.game_input('INVOKE_DEFAULT')
        
        self.report({'INFO'}, "Galaga started! Press SPACE to play.")
        return {'FINISHED'}


class GALAGA_OT_stop_game(bpy.types.Operator):
    """Stop the Galaga game"""
    bl_idname = "galaga.stop_game"
    bl_label = "Stop Game"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        global _game_timer, _modal_operator
        
        # Unregister timer
        if _game_timer:
            try:
                bpy.app.timers.unregister(_game_timer)
            except:
                pass
            _game_timer = None
        
        _modal_operator = None
        
        # Destroy game
        destroy_game()
        
        self.report({'INFO'}, "Galaga stopped!")
        return {'FINISHED'}


def game_callback():
    """Game loop callback"""
    game = get_game()
    if game:
        game.update()
    return 1.0 / 60.0


# Modal operator for input handling
class GALAGA_OT_game_input(bpy.types.Operator):
    """Modal input handler for the game"""
    bl_idname = "galaga.game_input"
    bl_label = "Galaga Input"
    bl_options = {'REGISTER'}  # No UNDO for modal input handlers
    
    def invoke(self, context, event):
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        game = get_game()
        
        if not game:
            return {'CANCELLED'}
        
        # Handle key events
        if event.type == 'LEFT_ARROW' or (event.type == 'A' and not event.shift):
            if event.value == 'PRESS':
                game.keys_pressed.add('LEFT')
            elif event.value == 'RELEASE':
                game.keys_pressed.discard('LEFT')
        
        elif event.type == 'RIGHT_ARROW' or (event.type == 'D' and not event.shift):
            if event.value == 'PRESS':
                game.keys_pressed.add('RIGHT')
            elif event.value == 'RELEASE':
                game.keys_pressed.discard('RIGHT')
        
        elif event.type == 'SPACE':
            if event.value == 'PRESS':
                game.keys_pressed.add('SPACE')
            elif event.value == 'RELEASE':
                game.keys_pressed.discard('SPACE')
        
        elif event.type == 'P':
            if event.value == 'PRESS':
                game.keys_pressed.add('P')
            elif event.value == 'RELEASE':
                game.keys_pressed.discard('P')
        
        elif event.type == 'R':
            if event.value == 'PRESS':
                game.keys_pressed.add('R')
            elif event.value == 'RELEASE':
                game.keys_pressed.discard('R')
        
        elif event.type == 'ESC':
            # Stop game on escape
            bpy.ops.galaga.stop_game()
            return {'CANCELLED'}
        
        return {'PASS_THROUGH'}
    
    def execute(self, context):
        return {'FINISHED'}


class GALAGA_PT_panel(bpy.types.Panel):
    """Main panel for Galaga game"""
    bl_label = "Galaga"
    bl_idname = "GALAGA_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Galaga'
    
    def draw(self, context):
        layout = self.layout
        
        game_running = get_game() is not None
        
        if not game_running:
            layout.label(text="Classic Galaga Game")
            layout.label(text="Play in Blender viewport!")
            layout.separator()
            layout.label(text="Controls:")
            layout.label(text="←/→ or A/D : Move")
            layout.label(text="SPACE : Fire")
            layout.label(text="P : Pause")
            layout.label(text="R : Restart")
            layout.separator()
            
            layout.operator("galaga.start_game", icon='PLAY')
        else:
            game = get_game()
            layout.label(text=f"State: {game.state.upper()}")
            layout.label(text=f"Score: {game.ui.score}")
            layout.label(text=f"Level: {game.enemies.level}")
            layout.label(text=f"Lives: {game.player.lives}")
            layout.separator()
            
            layout.operator("galaga.stop_game", icon='CANCEL')


def register():
    """Register the addon"""
    bpy.utils.register_class(GALAGA_OT_start_game)
    bpy.utils.register_class(GALAGA_OT_stop_game)
    bpy.utils.register_class(GALAGA_OT_game_input)
    bpy.utils.register_class(GALAGA_PT_panel)


def unregister():
    """Unregister the addon"""
    # Stop game first
    destroy_game()
    
    # Unregister classes
    bpy.utils.unregister_class(GALAGA_PT_panel)
    bpy.utils.unregister_class(GALAGA_OT_game_input)
    bpy.utils.unregister_class(GALAGA_OT_stop_game)
    bpy.utils.unregister_class(GALAGA_OT_start_game)


# Run registration
if __name__ == "__main__":
    register()
