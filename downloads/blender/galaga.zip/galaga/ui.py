"""
Galaga UI Module
Handles in-game UI display using Blender text objects
"""

import bpy
from .constants import *


class GameUI:
    """In-game user interface"""
    
    def __init__(self):
        self.score_text = None
        self.high_score_text = None
        self.lives_text = None
        self.level_text = None
        self.message_text = None
        self.score = 0
        self.high_score = 0
        self.lives = 3
        self.level = 1
        
    def create(self):
        """Create UI text objects"""
        # Score text
        self.score_text = self._create_text_object("ScoreText", "SCORE: 000000", 
                                                    UI_SCORE_OFFSET[0], UI_SCORE_OFFSET[1])
        
        # High score text  
        self.high_score_text = self._create_text_object("HighScoreText", "HIGH: 000000",
                                                         UI_HIGH_SCORE_OFFSET[0], UI_HIGH_SCORE_OFFSET[1])
        
        # Lives text
        self.lives_text = self._create_text_object("LivesText", "LIVES: ###",
                                                    UI_LIVES_OFFSET[0], UI_LIVES_OFFSET[1])
        
        # Level text
        self.level_text = self._create_text_object("LevelText", "LEVEL 1",
                                                    UI_SCORE_OFFSET[0], UI_SCORE_OFFSET[1] - 2)
        
        # Message text (for game states)
        self.message_text = self._create_text_object("MessageText", "",
                                                      0, 0, size=1.2)
        
        self.update()
    
    def _create_text_object(self, name, text, x, y, size=UI_TEXT_SIZE):
        """Create a text object in the scene"""
        # Create object with text
        bpy.ops.object.text_add(location=(x, y, 1))
        text_obj = bpy.context.active_object
        text_obj.name = name
        
        # Set the text content
        text_obj.data.body = text
        
        # Configure text
        text_obj.data.size = size
        text_obj.data.align_x = 'CENTER'
        text_obj.data.align_y = 'CENTER'
        
        # Create material
        mat = bpy.data.materials.new(name=name + "Mat")
        mat.use_nodes = True
        nodes = mat.node_tree.nodes
        principled = nodes.get("Principled BSDF")
        principled.inputs["Base Color"].default_value = (1, 1, 1, 1)
        principled.inputs["Emission Color"].default_value = (1, 1, 1, 1)
        principled.inputs["Emission Strength"].default_value = 1.0
        
        text_obj.data.materials.append(mat)
        
        return text_obj
    
    def update(self):
        """Update UI displays"""
        # Score
        if self.score_text:
            self.score_text.data.body = f"SCORE: {self.score:06d}"
        
        # High score
        if self.high_score_text:
            self.high_score_text.data.body = f"HIGH: {self.high_score:06d}"
        
        # Lives (as ship symbols)
        lives_str = "LIVES: " + "▲" * self.lives
        if self.lives_text:
            self.lives_text.data.body = lives_str
        
        # Level
        if self.level_text:
            self.level_text.data.body = f"LEVEL {self.level}"
    
    def set_message(self, message):
        """Display a message"""
        if self.message_text:
            self.message_text.data.body = message
    
    def clear_message(self):
        """Clear message"""
        if self.message_text:
            self.message_text.data.body = ""
    
    def show_ready(self):
        """Show ready message"""
        self.set_message("PRESS SPACE TO START")
    
    def show_paused(self):
        """Show paused message"""
        self.set_message("PAUSED")
    
    def show_game_over(self):
        """Show game over message"""
        self.set_message("GAME OVER\nPRESS R TO RESTART")
    
    def add_score(self, points):
        """Add to score"""
        self.score += points
        if self.score > self.high_score:
            self.high_score = self.score
        self.update()
    
    def set_lives(self, lives):
        """Set lives"""
        self.lives = lives
        self.update()
    
    def set_level(self, level):
        """Set level"""
        self.level = level
        self.update()
    
    def reset(self):
        """Reset UI state"""
        self.score = 0
        self.lives = 3
        self.level = 1
        self.clear_message()
        self.update()
    
    def cleanup(self):
        """Remove UI objects"""
        for obj in [self.score_text, self.high_score_text, self.lives_text, 
                    self.level_text, self.message_text]:
            if obj:
                bpy.data.objects.remove(obj, do_unlink=True)
