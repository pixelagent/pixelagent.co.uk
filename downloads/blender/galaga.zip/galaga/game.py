"""
Galaga Game Core Module
Main game logic, state management, and update loop
"""

import bpy
import random
from .constants import *
from .player import Player
from .enemies import EnemyFormation
from .projectiles import ProjectileManager
from .ui import GameUI


class GalagaGame:
    """Main game controller"""
    
    def __init__(self):
        self.state = GAME_STATE_READY
        self.player = Player()
        self.enemies = EnemyFormation()
        self.projectiles = ProjectileManager()
        self.ui = GameUI()
        
        self.keys_pressed = set()
        self.game_time = 0
        
    def initialize(self):
        """Initialize the game scene"""
        self._setup_camera()
        self._setup_background()
        
        # Create player
        self.player.create()
        
        # Create enemies
        self.enemies.create()
        
        # Create UI
        self.ui.create()
        
        # Show ready message
        self.ui.show_ready()
        
    def _setup_camera(self):
        """Setup orthographic camera for game view"""
        # Check if camera exists
        camera = None
        for obj in bpy.data.objects:
            if obj.type == 'CAMERA':
                camera = obj
                break
        
        if not camera:
            # Create new camera
            bpy.ops.object.camera_add(location=(0, 0, 50))
            camera = bpy.context.active_object
            camera.name = "GameCamera"
        
        # Configure camera
        camera.data.type = 'ORTHO'
        camera.data.ortho_scale = 35
        
        # Point camera at origin (down -Z)
        camera.rotation_euler = (0, 0, 0)
        
        # Set as active camera
        bpy.context.scene.camera = camera
    
    def _setup_background(self):
        """Setup background"""
        # Set viewport background to dark (with guard for missing world/nodes)
        world = bpy.context.scene.world
        if world and world.use_nodes and "Background" in world.node_tree.nodes:
            world.node_tree.nodes["Background"].inputs[0].default_value = COLOR_BACKGROUND
        
        # Create stars (simple particles or small spheres)
        for i in range(50):
            x = random.uniform(PLAY_AREA_MIN_X - 10, PLAY_AREA_MAX_X + 10)
            y = random.uniform(PLAY_AREA_MIN_Y - 10, PLAY_AREA_MAX_Y + 10)
            
            bpy.ops.mesh.primitive_uv_sphere_add(
                segments=4,
                ring_count=2,
                radius=0.1,
                location=(x, y, -1)
            )
            star = bpy.context.active_object
            star.name = f"Star_{i}"
            
            # Dim white material
            mat = bpy.data.materials.new(name=f"StarMat_{i}")
            mat.use_nodes = True
            nodes = mat.node_tree.nodes
            principled = nodes.get("Principled BSDF")
            brightness = random.uniform(0.3, 0.8)
            principled.inputs["Base Color"].default_value = (brightness, brightness, brightness, 1)
            
            star.data.materials.append(mat)
    
    def handle_input(self):
        """Handle keyboard input"""
        if self.state == GAME_STATE_READY:
            if 'SPACE' in self.keys_pressed:
                self.start_game()
        
        elif self.state == GAME_STATE_PLAYING:
            # Player movement
            if 'LEFT' in self.keys_pressed or 'A' in self.keys_pressed:
                self.player.move_left(GAME_TICK)
            if 'RIGHT' in self.keys_pressed or 'D' in self.keys_pressed:
                self.player.move_right(GAME_TICK)
            
            # Shooting
            if 'SPACE' in self.keys_pressed:
                px, py = self.player.get_position()
                self.projectiles.player_shoot(px, py)
            
            # Pause
            if 'P' in self.keys_pressed:
                self.keys_pressed.discard('P')
                self.toggle_pause()
        
        elif self.state == GAME_STATE_PAUSED:
            if 'P' in self.keys_pressed:
                self.keys_pressed.discard('P')
                self.toggle_pause()
        
        elif self.state == GAME_STATE_GAME_OVER:
            if 'R' in self.keys_pressed:
                self.keys_pressed.discard('R')
                self.restart_game()
    
    def start_game(self):
        """Start the game"""
        self.state = GAME_STATE_PLAYING
        self.ui.clear_message()
    
    def toggle_pause(self):
        """Toggle pause state"""
        if self.state == GAME_STATE_PLAYING:
            self.state = GAME_STATE_PAUSED
            self.ui.show_paused()
        elif self.state == GAME_STATE_PAUSED:
            self.state = GAME_STATE_PLAYING
            self.ui.clear_message()
    
    def restart_game(self):
        """Restart the game"""
        # Cleanup
        self.player.cleanup()
        self.enemies.cleanup()
        self.projectiles.cleanup()
        self.ui.cleanup()
        
        # Reset
        self.player = Player()
        self.enemies = EnemyFormation()
        self.projectiles = ProjectileManager()
        self.ui = GameUI()
        
        # Recreate
        self.initialize()
        self.state = GAME_STATE_PLAYING
        self.ui.clear_message()  # Clear the ready message
    
    def update(self):
        """Main game update"""
        self.handle_input()
        
        if self.state != GAME_STATE_PLAYING:
            return
        
        self.game_time += GAME_TICK
        
        # Update player
        self.player.update(GAME_TICK)
        
        # Update enemies
        self.enemies.update(GAME_TICK)
        
        # Enemy shooting
        if random.random() < ENEMY_SHOOT_CHANCE * self.enemies.alive_count:
            diving_enemy = self.enemies.get_random_diving_enemy()
            if diving_enemy:
                self.projectiles.enemy_shoot(diving_enemy.x, diving_enemy.y)
            else:
                # Random alive enemy from formation
                alive = [e for e in self.enemies.enemies if e.alive and not e.diving and not e.returning]
                if alive:
                    enemy = random.choice(alive)
                    self.projectiles.enemy_shoot(enemy.x, enemy.y)
        
        # Update projectiles
        self.projectiles.update(GAME_TICK)
        
        # Check collisions
        self._check_collisions()
        
        # Check for level complete
        if self.enemies.is_cleared():
            self._next_level()
    
    def _check_collisions(self):
        """Check all collisions"""
        # Player bullets vs Enemies
        for bullet in self.projectiles.player_bullets[:]:
            if not bullet.alive:
                continue
                
            enemy = self.enemies.get_enemy_at(bullet.x, bullet.y, bullet.collision_radius)
            if enemy and enemy.alive:
                # Hit!
                enemy.alive = False
                bullet.alive = False
                self.projectiles.create_explosion(enemy.x, enemy.y)
                self.ui.add_score(enemy.points)
                
                # Remove enemy
                enemy.cleanup()
                self.enemies._update_alive_count()
                
                # Remove bullet
                bullet.cleanup()
                if bullet in self.projectiles.player_bullets:
                    self.projectiles.player_bullets.remove(bullet)
        
        # Enemy bullets vs Player
        if self.player.is_alive and not self.player.invulnerable:
            for bullet in self.projectiles.enemy_bullets[:]:
                if not bullet.alive:
                    continue
                    
                dx = bullet.x - self.player.x
                dy = bullet.y - self.player.y
                dist = (dx*dx + dy*dy)**0.5
                
                if dist < bullet.collision_radius + self.player.collision_radius:
                    # Player hit!
                    bullet.alive = False
                    bullet.cleanup()
                    if bullet in self.projectiles.enemy_bullets:
                        self.projectiles.enemy_bullets.remove(bullet)
                    
                    self._player_hit()
        
        # Diving enemies vs Player
        if self.player.is_alive and not self.player.invulnerable:
            for enemy in self.enemies.enemies:
                if enemy.alive and enemy.diving:
                    dx = enemy.x - self.player.x
                    dy = enemy.y - self.player.y
                    dist = (dx*dx + dy*dy)**0.5
                    
                    if dist < enemy.collision_radius + self.player.collision_radius:
                        enemy.alive = False
                        enemy.cleanup()
                        self.projectiles.create_explosion(enemy.x, enemy.y)
                        self.ui.add_score(enemy.points)
                        self.enemies._update_alive_count()
                        self._player_hit()
    
    def _player_hit(self):
        """Handle player getting hit"""
        self.projectiles.create_explosion(self.player.x, self.player.y)
        
        if self.player.hit():
            # Game over
            self.state = GAME_STATE_GAME_OVER
            self.ui.show_game_over()
        else:
            # Respawn
            self.player.respawn()
            self.ui.set_lives(self.player.lives)
    
    def _next_level(self):
        """Advance to next level"""
        # Clean up old enemies first
        self.enemies.cleanup()
        
        self.enemies.level += 1
        self.ui.set_level(self.enemies.level)
        
        # Create new formation
        self.enemies.create()
    
    def cleanup(self):
        """Cleanup game objects"""
        self.player.cleanup()
        self.enemies.cleanup()
        self.projectiles.cleanup()
        self.ui.cleanup()
        
        # Remove stars
        for obj in bpy.data.objects:
            if obj.name.startswith("Star_"):
                bpy.data.objects.remove(obj, do_unlink=True)


# Global game instance
_game_instance = None


def get_game():
    """Get the global game instance"""
    global _game_instance
    return _game_instance


def create_game():
    """Create and initialize the game"""
    global _game_instance
    _game_instance = GalagaGame()
    _game_instance.initialize()
    return _game_instance


def destroy_game():
    """Destroy the game instance"""
    global _game_instance
    if _game_instance:
        _game_instance.cleanup()
        _game_instance = None
